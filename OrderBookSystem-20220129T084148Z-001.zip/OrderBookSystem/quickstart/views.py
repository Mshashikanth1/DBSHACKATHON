from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from quickstart.models import *
from quickstart.serializers import *

# Create your views here.
@csrf_exempt
def loginUser(request):
    if request.method == 'GET':
        serializer = UserSerializer()
        userData = {}
        if request.body.email:
            userData = {
                'email': request.body.email,
                'password': request.body.password
            }
        else:
            userData = {
                'username': request.body.username,
                'password': request.body.password
            }
        user = serializer.getByUserNameOrEmailAndPassword(userData)
        if user:
            return JsonResponse(user, status=201)
        else:
            return JsonResponse(NULL, status=400)
    return JsonResponse(NULL, status=400)

@csrf_exempt
def createStocks(request):
    if request.method == 'POST':
        serializer = StocksSerializer(request.body)
        if serializer.is_valid:
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(NULL, status=400)
    return JsonResponse(NULL, status=400)

@csrf_exempt
def createStockOrders(request):
    if request.method == 'POST':
        serializer = StockOrdersSerializer(request.body)
        if serializer.is_valid:
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.data, status=400)
    return JsonResponse(NULL, status=400)

@csrf_exempt
def getAllExecutionOrders(request):
    if request.method == 'GET':
        eoSerializer = ExecutionOrdersSerializer()
        eoDocs = eoSerializer.getAll()
        if len(eoDocs) > 0:
            return JsonResponse(eoDocs, status=201)
        elif len(eoDocs) == 0:
            serializer = StockOrdersSerializer()
            docs = serializer.getAll()
            data = []
            for doc in docs:
                data.append({
                    'orderId': doc.id,
                    'stockId': doc.stockId,
                    'stockName': doc.stockId.name,
                    'orderQty': doc.quantity,
                    'orderType': doc.orderType,
                    'executedQty': 0,
                    'price': doc.price,
                    'status': EXECUTION_STATUS.PLACED,
                    'orderDate': doc.orderDate
                })
            return JsonResponse(data, status = 201)
    return JsonResponse(NULL, status=400)

@csrf_exempt
def executeOrders(request):
    if request.method == 'PUT':
        assignmentData = request.body
        serializer = StockOrdersSerializer()
        noOfStockOrders = serializer.getByPrice(assignmentData.executionPrice)
        perQuantity = assignmentData.executionPrice // noOfStockOrders
        for data in assignmentData.stockOrders:
            if data.price == assignmentData.executionPrice:
                if id not in data:
                    docData = {
                        'stockId': data.stockId,
                        'price': data.price,
                        'quantity': data.quantity,
                        'orderType': data.orderType,
                        'executedQuantity': perQuantity,
                        'executedPrice': assignmentData.executionPrice,
                        'orderStatus': EXECUTION_STATUS.PLACED,
                        'orderDate': data.orderDate
                    }
                    eoSerializer = ExecutionOrdersSerializer(docData)
                    if eoSerializer.is_valid:
                        eoSerializer.save()
                    else:
                        return JsonResponse(NULL, status=400)
                else:
                    eoSerializer = ExecutionOrdersSerializer()
                    instance = eoSerializer.getById(data.id)
                    docData = {
                        'executeQty': assignmentData.executionQty,
                        'noOfStockOrders': noOfStockOrders,
                        'price': data.price,
                        'quantity': data.quantity,
                        'executePrice': assignmentData.executionPrice
                    }
                    updatedInstance = eoSerializer.update(instance, docData)
        return JsonResponse('Success', status=201)
    return JsonResponse(NULL, status=400)
        




