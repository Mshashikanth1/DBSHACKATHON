from django.urls import path

from . import views

urlpatterns = [
    path('login', views.loginUser, name='loginUser'),
    path('stocks-add', views.createStocks, name='createStocks'),
    path('stock-orders', views.createStockOrders, name='createStockOrders'),
    path('execution-orders', views.getAllExecutionOrders, name='getAllExecutionOrders'),
    path('execute-orders', views.executeOrders, name='executeOrders')
]