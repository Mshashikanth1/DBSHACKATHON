from rest_framework import serializers
from quickstart.models import *

# service for user model used for crud ops.
class UserSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    username = serializers.CharField(max_length=500, allow_blank=True, required=False)
    email = serializers.EmailField()
    password = serializers.CharField(max_length=50)
    isAdmin = serializers.BooleanField(default=False)

    def create(self, validated_data):
        return User.objects.create(**validated_data)

    def getByUserNameOrEmailAndPassword(self, data):
        return User.objects.get(username=data.username, password = data.password) | User.objects.get(email=data.email, password=data.password)

    
class StocksSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    name = serializers.CharField(max_length=500,required=True,allow_blank=False)
    price = serializers.FloatField()
    quantity = serializers.IntegerField()

    def getAll(self):
        return Stocks.objects.all()

    def create(self, validated_data):
        return Stocks.objects.create(**validated_data)

class StockOrdersSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    stockId = serializers.PrimaryKeyRelatedField(many=True, readOnly=True)
    userId = serializers.PrimaryKeyRelatedField(many=True, readOnly=True)
    orderType = serializers.CharField(max_length=50,choices = ORDER_TYPES.choices)
    price = serializers.FloatField()
    quantity = serializers.IntegerField()
    orderDate = serializers.DateField()

    def getAll(self):
        return StockOrders.objects.all()

    def getByPrice(self, price):
        return StockOrders.objects.get(price = price)

    def create(self, data):
        return StockOrders.objects.create(**data)

class ExecutionOrdersSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    stockId = serializers.PrimaryKeyRelatedField(many=True, readOnly=True)
    price = serializers.FloatField()
    quantity = serializers.IntegerField()
    orderType = serializers.CharField(max_length=50,choices = ORDER_TYPES.choices)
    executedQty = serializers.IntegerField()
    executePrice = serializers.FloatField()
    orderStatus = serializers.CharField(max_length=50,choices=EXECUTION_STATUS.choices)
    orderDate = serializers.DateField()

    def getAll(self):
        return ExecutionOrders.objects.all()

    def create(self, data):
        return ExecutionOrders.objects.create(**data)

    def getById(self, id):
        return ExecutionOrders.objects.get(pk=id)

    def update(self, instance, data):
        executeQty = data['executeQty'] // data['noOfStockOrders']
        instance.executeQty += executeQty
        if instance.orderType == ORDER_TYPES.Market and data.price < data.executePrice:
            instance.orderStatus = EXECUTION_STATUS.REJECTED
        else:
            if instance.executeQty == data.quantity:
                instance.orderStatus = EXECUTION_STATUS.EXECUTED
            else:
                instance.orderStatus = EXECUTION_STATUS.ACCEPTED
        instance.save()
        return instance



