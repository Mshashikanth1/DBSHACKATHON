from django.db import models

class ORDER_TYPES(models.TextChoices):
    Limit = 'Limit'
    Market = 'Market'

class EXECUTION_STATUS(models.TextChoices):
    PLACED = 'PLACED'
    ACCEPTED = 'ACCEPTED'
    REJECTED = 'REJECTED'
    EXECUTED = 'EXECUTED'


# Create your models here.
class User(models.Model):
    username = models.CharField(max_length=500, blank=True, default='')
    email = models.EmailField()
    password = models.CharField(max_length=50)
    isAdmin = models.BooleanField(default=False)

class Stocks(models.Model):
    name = models.CharField(max_length=500,blank=False)
    price = models.FloatField()
    quantity = models.BigIntegerField()

class StockOrders(models.Model):
    stockId = models.ForeignKey('Stocks', on_delete=models.DO_NOTHING)
    userId = models.ForeignKey('User', on_delete=models.DO_NOTHING)
    orderType = models.CharField(max_length=50,choices = ORDER_TYPES.choices)
    price = models.FloatField()
    quantity = models.BigIntegerField()
    orderDate = models.DateField()

class ExecutionOrders(models.Model):
    stockId = models.ForeignKey('Stocks', on_delete=models.DO_NOTHING)
    price = models.FloatField()
    quantity = models.BigIntegerField()
    orderType = models.CharField(max_length=50,choices = ORDER_TYPES.choices)
    executedQty = models.BigIntegerField()
    executePrice = models.FloatField()
    orderStatus = models.CharField(max_length=50,choices=EXECUTION_STATUS.choices)
    orderDate = models.DateField()


